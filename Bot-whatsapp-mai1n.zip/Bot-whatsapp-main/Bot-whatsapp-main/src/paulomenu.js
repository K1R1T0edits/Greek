const paulomenu = (prefix, pushname) => {
    return `◪ *Comandos do 𝗔𝗥𝗥157 𝗕𝗢𝗧*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.paulomenu = paulomenu
